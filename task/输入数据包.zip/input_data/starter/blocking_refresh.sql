-- 错误起点：没有唯一索引，无法使用CONCURRENTLY；
-- 也在刷新前更新水位，失败时会把未发布数据标成已刷新。
UPDATE analytics.refresh_watermark
SET source_received_through = (SELECT max(received_at) FROM app.content_event);
REFRESH MATERIALIZED VIEW analytics.content_hourly_rank;
